I have use import export in this project for saving the scores,
so make sure the location to the saved_scores file is given in the code